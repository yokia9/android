<html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<title>MaxproLive</title>
   <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Ubuntu&display=swap" rel="stylesheet">
<link rel="shortcut icon" type="image/x-icon" href="https://dthhyderabad.in/wp-content/uploads/2019/09/1.jpg">
<meta name="robots" content="noindex">
<style>   *{

        font-family: 'Ubuntu', sans-serif;
         }
 .box1 {

         display: inline-block;
         border:2px solid black;
         text-align:center;
         align-items:center;
         margin:10px;
         background-color:#FDEBD0;
         border-radius:1.5rem;
         text-align:center;
         margin-left:-.8rem;
         margin-right:.5rem;
         height:auto;

         }
         
         .container {Width:100%;
margin-left:.6rem;}

         
         .box1:hover{
             background-color: #92DCA1;
			 border-color:white;
			 border:4px solid white;
         }

         body {
                       text-align:center;
         align-items:center;
         background-image:url("https://images.hdqwalls.com/download/abstract-simple-background-4k-lp-1366x768.jpg");
         }

         .box1 a {

         text-decoration: none;
         color: black;
         line-height:10px ;
         background-color:red;
         
         }

         input:focus{

         transition: cubic-bezier(0.075, 0.82, 0.165, 1);
                    border-color:red;
         }

         h1 {

         font-family:: Georgia, 'Times New Roman', Times, serif;
         }

         #brand{

         text-decoration:none;
         color: white;
         }

         select{
             text-align: center;
         width:40%;
         height:38px;
         border: 1.5px solid yellow;
            border-radius:1rem;margin-left:-1.2rem;
         }

         option{
                 line-height:35px ;
                 border: 1px solid black;
                 border-radius:1.5rem;
                 font-size:18px;

         }

           input{

         width:40%;
         height:38px;
         border: 1.5px solid yellow;
         text-align: center;
            border-radius:1rem;
            font-size:18px;
            margin-left:-.4rem;
         }
         }

         .con   {

           display:flexbox;
           width:100%;
           margin:15px;
         margin:10px;
         text-align: center;


         }

         .dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  width:100%;
  border-radius:1rem;
  background-color:orangered;
  font-size: 16px;
  border: none;
  cursor: pointer;

}

.dropdown {
  position: relative;
  display: inline-block;
  width: :80% ;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 100%;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}


         @media only screen and (max-width: 768px) {
 select, input, .drpbtn , .dropdown{
    width:85%;
  }

  .
}


</style>
<script src="https://cdn.jsdelivr.net/npm/lazysizes@5.3.2/lazysizes.min.js"></script>
</head>
<body>

<div id="jtvh1">
<a id="brand" href="#">
<h1>Maxpro Live [ ZEE5 ]</h1>
</a>
</div>
<br>
                 
		<br><br><div class="con" >
    <div class="dropdown">
  <button class="dropbtn">Select Plateform</button>
  <div class="dropdown-content">
 
<a href="./index.php">JIO TV</a>
<a href="./zee5.php"> ZEE5</a>
  <a href="./sony.php">SONY LIV</a>
  
  </div>
</div> <br> <br>

 <form>
     <input id="search" type="search" placeholder="Search"/>
 </form>
</div>
<div id="content">
<div class="container">



<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeecinemahd"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeecinemahd/channel_web/1170x658withlogo167952257" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Cinema HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeecinemalu"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeecinemalu/channel_web/1170x6581642453232" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Cinemalu HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-tvpictureshd"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-tvpictureshd/channel_web/1170x658withlog1476130363" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">&amp;Pictures HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeetalkies"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeetalkies/channel_web/1170x658483062857" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Talkies HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeeanmolcinema"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeeanmolcinema/channel_web/1170x658withlog_1721007595" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Anmol Cinema</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeeclassic"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeeclassic/channel_web/1170x658e6b59efbc9c5471f9392f477f91f0c11" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Bollywood</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeecinema"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeecinema/channel_web/1170x658withlogo_807278654" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Cinema</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-pictures"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-pictures/channel_web/1170x658withlog_1269578414" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">&amp;Pictures</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeeaction"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeeaction/channel_web/1170x658withlog_1953200347" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Action</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-privéhd"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-privéhd/channel_web/1170x658withlogo375086496" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">&amp;Prive HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-channel_2105335046"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-channel_2105335046/channel_web/1170x658379547401" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">&amp;flix HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-176"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-176/channel_web/1170x658d4d3573a17f24dcdb86c0da75e7208e8" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Classic</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-209"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-209/channel_web/1170x658withlogo358457080" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">&amp;xplorHD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-216"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-216/channel_web/1170x658withlogo20909261" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Biskope</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-224"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-224/channel_web/1170x658withlogo_334138193" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Thirai</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-394"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-394/channel_web/1170x658717187404" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Chitramandir</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-aajtak"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-aajtak/channel_web/aajtak117075e453cde75a4fcbbd98b890266dcb21" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Aaj Tak</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeenews"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeenews/channel_web/zeenews117058a10e260ccf453885b0b866b6efcf8c" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-162"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-162/channel_web/anchorbanners11704f82e6a64233425f9ccc065f88214e34" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Republic Bharat</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeebusiness"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeebusiness/channel_web/zeebusiness117088d767ebaf91485992201f5422d49bb1" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Business</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-170"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-170/channel_web/newsnation1170c28d164cac8b46d48dd03c24f22a2611" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News Nation</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-257"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-257/channel_web/tv9marathi1170c5bded27d1644b18a5624c7dd3c33d3b" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV9 Marathi</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-indiatoday"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-indiatoday/channel_web/indiatodayrajeevsardesdai117023f79b66b4d4466ea52534491c162c35" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">India Today</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-306"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-306/channel_web/vendhartv1170ea466f03c5984481876c4200bd6bb22d" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Vendhar TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-258"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-258/channel_web/tv9telugu117006600b0482a24377bec3b6b67e0b48c9" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV9 Telugu</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-222"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-222/channel_web/1170x658withlogo273514222953081f2a5264d2199171a94a0135187" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV5 News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-270"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-270/channel_web/saamtv117064848316bfb4424ab360060c0214cec9" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Saam TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-282"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-282/channel_web/indiatv1170598b3b1a8dde4800bcff6b4bc7ec02cc" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">India TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeepunjabharyanahima"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeepunjabharyanahima/channel_web/zphh14405b673f1d0f8a43969c82a3c67dff3dad" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Punjab Haryana Himachal Pradesh</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-251"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-251/channel_web/tv9bharatvarshb1170e3167ef254394aa0b6ff7a978bdbc921" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV9 Bharatvarsh</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-206"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-206/channel_web/e24newslogob1170d070a62b9582496dbaaf4a73a3430376" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News24</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-channel_1422341819"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-channel_1422341819/channel_web/rtv11708043efd184cc497facd3cc4387cbb108" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Republic TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-260"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-260/channel_web/tv9gujarati1170f3923ce988484dd0a81cd0bec994e377" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV9 Gujarati</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zee24kalak"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zee24kalak/channel_web/zee24kalak117026f0ebf7a57941d79fd9fdd74a2d6f26" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee 24 Kalak</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-259"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-259/channel_web/tv9kannada1170035730f6801c4ba0b1d905a61bbc9dcd" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV9 Kannada</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-201"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-201/channel_web/1170x658_503553443" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Suvarna News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zee24taas"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zee24taas/channel_web/zee24taas11707d845042f4ef453a8568b6ba22b3f568" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee 24 Taas</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-255"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-255/channel_web/gnt11709b84a70ae43a4fcab837620b97c80f5f" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Good News Today</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-wion"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-wion/channel_web/wion117087793a1cce2d4dcaa4274d5bfc6d5a96" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">WION</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeehindustan"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeehindustan/channel_web/zeehindustan11708e67b053f5e1461abb55377b1c939336" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Hindustan</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeebiharjharkhand"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeebiharjharkhand/channel_web/zeebiharjharkhandb117099e2787548354a5abd1c2230a5bee898" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Bihar Jharkhand</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-171"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-171/channel_web/newsstateuttarpradeshuttrakhand117057fc4c96dc444886b421570253e13a6a" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News State Uttar Pradesh Uttrakhand</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-24ghantatv"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-24ghantatv/channel_web/anchorbanners117074b09be61e5a4f27b38cbbdc9527fc02" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">24 Ghanta</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeekalinganews"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeekalinganews/channel_web/zeeodisha11707ef6fbab0159428bbe1a3196370fa851" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Odisha</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeerajasthannews"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeerajasthannews/channel_web/zeerajasthanb1170751ba3f9900e44b9a49f06e4e37042db" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Rajasthan News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeemadhyapradeshchat"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeemadhyapradeshchat/channel_web/zeemadhyapradeshchhattisgarh1170342c565feaf141ccb6e5b39d2ce0e71d" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Madhya Pradesh Chhattisgarh</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-chardiklatimetvtimet"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-chardiklatimetvtimet/channel_web/chardiklatimetv1170803e29eda81041f481cabfbcf63c406a" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Chardikla Time TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddnews"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddnews/channel_web/ddnews11705b93d38449604b94b8b715cef36f33c6" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddindia"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddindia/channel_web/ddindiab117082f1e0ff4e50404a97f9e4ea810d0d64" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD India</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddkisan"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddkisan/channel_web/ddkisan1170dd6893e0dd6d49c1aa725b8981c6ccdb" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Kisan</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeesalaam"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeesalaam/channel_web/zeesalaam1170007fc0a564444dd68d57bb1e95619dc2" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Salaam</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddyadagiri"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddyadagiri/channel_web/ddyadagiri1170fb5c4623571b43a5b0fc6a728e6d6aa0" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Yadagiri</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-channel_265145625"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-channel_265145625/channel_web/zeeupukb1170a14076402a564513b88b488a90421d59" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee News Uttar Pradesh Uttrakhand</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-172"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-172/channel_web/newsstatempch11705453127ff9284c43b982e7e52d76641c" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News State Madhya Pradesh Chhattisgarh</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-200"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-200/channel_web/pgsureshkumarne_1752938193" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Asianet News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-227"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-227/channel_web/tv5kannada1170aaeef9c71d264307ae6263b453520611" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV5 Kannada</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-272"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-272/channel_web/indianews117031f8a5ac002d4997aacd1577d390d3b0" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">India News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-273"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-273/channel_web/newsx11705f1b6520fc254daebac5828ac093b798" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News X</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-274"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-274/channel_web/indianewspunjabhimachal1170c83368ea85274c9984dfbb31a8d9619b" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">India News Punjabi Himachal</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-275"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-275/channel_web/indianewsupuk1170699189b29da0419780b604b5b27a1d5e" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">India News UP</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-276"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-276/channel_web/indianewsrajasthan11709eea0d2513e04c16b39ed265596df0e5" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">India News Rajasthan</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-277"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-277/channel_web/indianewsmp1170cb5cf71c7f1141f8be18c083970cf4ed" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">India News MP</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-278"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-278/channel_web/indianewsharyana11708fc221c14dcb40e389b3d9e1338a6c6c" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">India News Haryana</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-279"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-279/channel_web/indianewsgujarat1170d81d0752eea04c669df2dc37c1bd4f97" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">India News Gujarat</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-280"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-280/channel_web/nenews1170b76941073dff4b9382b14f80198b5105" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">NE News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-305"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-305/channel_web/livingindia1170df15a8430ba5461880eaec89eb8d05ef" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Living India</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-310"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-310/channel_web/pragnews11708e8cfbbd7cc342c09e27956a56a6084a" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Prag News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-313"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-313/channel_web/sadhnaplusnews117044705e58ca9749d08603adeec06c299d" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Sadhna Plus News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-314"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-314/channel_web/vipnews1170a39a47a1b0554f04ae96edb65b77d0fe" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">VIP News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-317"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-317/channel_web/time81170bcb518bfbd19440b8b482cad67ca7a8f" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TIME8</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-319"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-319/channel_web/sadhnanewsmpch11700de2a8f50653478c8a26b11904e279cc" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Sadhna News MP/CG</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-354"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-354/channel_web/bharatsamachar1170db49df94773d486194cba05b2d712ffe" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Bharat Samachar</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-355"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-355/channel_web/abnandhrajyothy11700427e7d0f53343ca8612a9caa4ed1edd" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ABN Andhra Jyothy</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-371"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-371/channel_web/10tv1170867ca01f83cd44a4b4e2c577590039f0" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">10TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-378"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-378/channel_web/tv9bangla11701498fb25d3fd4b4db18c5d4e05e83cc9ce" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV9 Bangla</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-383"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-383/channel_web/sudarshantv1170ab2c3555bfa44317922f02d2bdea03de" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Sudarshan TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-384"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-384/channel_web/dainiksavera1170fba0f7f5e89c488c893f6b80a54603d6" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Dainik Savera</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-385"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-385/channel_web/cnewsbharat1170058694df1b4b4b3eac921b188dff69f6" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">C News Bharat</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-386"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-386/channel_web/tv1001170ab5260f9aca74e2590f119c364bbf435" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV 100</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-387"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-387/channel_web/abstarnews11702861f1381130457292da3bde6f1bf2fc" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">AB Star News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-388"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-388/channel_web/sanjhisoch11708b74fd15cc674b69aa715814bb0f7a0f" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Sanjhi Soch</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-389"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-389/channel_web/euronewsb117009692741d8254698a3a35f9cef914b2e" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Euro News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-390"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-390/channel_web/africanewsb11702dce80531da94a959cf9be397d4f8469" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Africa News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-398"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-398/channel_web/abpnewssumitawasthi21170ef3a0d5743ed479aab0111e2440ca87b" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ABP News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-399"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-399/channel_web/abpganga1170e69c33f8e6d140fd8cd954177064b16b" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ABP Ganga</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-400"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-400/channel_web/abpmajha1170cb8e2b94f9244846a3be5bdaa87792f8" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ABP Majha</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-402"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-402/channel_web/abpananda1170326ed9e75816a6456b9e713f1f5bf83cc7" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ABP Ananda</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-403"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-403/channel_web/abpasmita1170e9877d844ae74d54910d4a1798720913" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ABP Asmita</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-404"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-404/channel_web/abpsanjha1170e043143edf5f4fa3be291347ddd15311" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ABP Sanjha</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-407"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-407/channel_web/1170x658671581899" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News Time Assam</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-408"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-408/channel_web/nd2411700106e77550ed4c70a5e578db7644f6a1" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ND24</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-410"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-410/channel_web/cvrnewstelugu117089dc3accd5114448a6db45530a8be68d" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">CVR News Telugu</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-411"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-411/channel_web/cvrenglish11702e7a7b9730fb46c2ba5c37f06bcb3d22" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">CVR English</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-413"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-413/channel_web/pratidintime1170afea806003d0418ab560e90ae675fb41" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Pratidin Time</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-417"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-417/channel_web/news1india117021bcedcc55e34d259ffce7b35189a0a3" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News1 India</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-418"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-418/channel_web/v611706da0a50feba64da09d710bfc70714d88" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">V6</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-423"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-423/channel_web/1170x658_1426309917" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Newsmax</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-424"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-424/channel_web/1170x658439820624" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Ticker News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-430"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-430/channel_web/sarath_1170" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Kairali News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-431"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-431/channel_web/rbangla1170" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Republic Bangla</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-9z583386"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-9z583386/channel_web/timesnownavbharat1170e4f4cbfa707b40e19ca7748eb6b27449" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Times Now Navbharat</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-9z583533"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-9z583533/channel_web/1170x65872e20eebb8c4416db5d5b1e014e2ab77" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ZEE News Tamil</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-9z583537"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-9z583537/channel_web/1170x65892ecf4aa8e934cdeb7deb9bbd501646d" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ZEE News Kannada</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-9z583538"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-9z583538/channel_web/1170x658fb1bd397310743bf850648fb036ae8b7" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee News Telugu</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-9z583539"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-9z583539/channel_web/1170x658f0313dbfc3ef4c0c9c4619454829b2d3" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ZEE News Malayalam</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-bigmagic_1786965389"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-bigmagic_1786965389/channel_web/1170x658withlog_2022520414" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Big Magic</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeetvhd"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeetvhd/channel_web/1170x658withlog1554775145" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee TV HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-tvhd_0"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-tvhd_0/channel_web/1170x658withlogo378606665" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">&amp;TV HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeemarathi"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeemarathi/channel_web/1170x658withlogo551054149" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Marathi HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeeyuva"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeeyuva/channel_web/1170x658withlogo_361849131" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Yuva</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeecafehd"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeecafehd/channel_web/1170x658withlogo325698699" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Café HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-bigganga"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-bigganga/channel_web/1170x6581735687172" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Ganga</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeetamil"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeetamil/channel_web/1170x6581250786368" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Tamil HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeetelugu"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeetelugu/channel_web/1170x658593933473" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Telugu HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeekannada"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeekannada/channel_web/1170x658611455469" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Kannada HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-129"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-129/channel_web/1170x658withlogo268830785" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Keralam HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeebangla"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeebangla/channel_web/1170x658310781121" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Bangla HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeeanmol"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeeanmol/channel_web/1170x658withlog_1844143347" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Anmol</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeebanglacinema"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeebanglacinema/channel_web/1170x658withlog1238879598" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Bangla Cinema</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-215"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-215/channel_web/1170x658withlog1031170304" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Punjabi</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddodia"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddodia/channel_web/1170x658withlog_1372768736" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Odia</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-165"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-165/channel_web/1170x658withlog_1849594732" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Boogle Bollywood</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-channel_2132977507"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-channel_2132977507/channel_web/1170x658withlog1071598760" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Alpha ETC Punjabi</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeetv"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeetv/channel_web/1170x658withlogo_200095097" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-makkaltv"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-makkaltv/channel_web/1170x658withlogo_579936187" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Makkal TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddpodhigai"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddpodhigai/channel_web/1170x658withlog_1550486077" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Podhigai</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddmalayalam"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddmalayalam/channel_web/1170x658withlog_1300475155" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Malayalam</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddbangla"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddbangla/channel_web/1170x658withlog_1242891543" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Bangla</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddchandana"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddchandana/channel_web/1170x658withlogo_222569298" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Chandana</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-sarthaktv"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-sarthaktv/channel_web/1170x658withlog1150431941" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Sarthak</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddsahyadri"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddsahyadri/channel_web/1170x658withlog1078376781" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Sahyadri</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddgirnar"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddgirnar/channel_web/1170x658withlog_1445842484" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Girnar</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddurdu"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddurdu/channel_web/1170x658withlog_1440959247" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Urdu</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddrajasthanjaipur"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddrajasthanjaipur/channel_web/1170x658withlog_1491909175" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Rajasthan</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddbharati"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddbharati/channel_web/1170x658withlog_1749264623" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Bharati</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddmadhyapradesh"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddmadhyapradesh/channel_web/1170x658withlog_1218231157" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Madhya Pradesh</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddbihar"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddbihar/channel_web/1170x658withlog_1865440648" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Bihar</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-dduttarpradesh"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-dduttarpradesh/channel_web/1170x658withlog_1445486903" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Uttar Pradesh</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddpunjabi"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddpunjabi/channel_web/1170x658withlog_1007647800" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Punjabi</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-241"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-241/channel_web/1170x658withlog_1692640342" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Picchar</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-250"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-250/channel_web/1170x658withlogo436360213" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD National HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-322"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-322/channel_web/1170x658withlog_1602476580" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Rengoni</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-24ghantatv"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-24ghantatv/channel_web/1170x658withlogo_644392845" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">24 Ghanta</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeebangla"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeebangla/channel_web/1170x658_310781121" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Bangla HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeebanglacinema"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeebanglacinema/channel_web/1170x658withlog_1238879598" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Bangla Cinema</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-channel_1144658965"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-channel_1144658965/channel_web/1170x658withlog_1152304152" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Sanskar TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-327"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-327/channel_web/1170x658withlog_2031259137" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Shubh TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-channel_1565694979"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-channel_1565694979/channel_web/1170x658withlogo_66703857" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Satsang TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-divyatv"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-divyatv/channel_web/1170x658withlog_2128007300" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Divya TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-166"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-166/channel_web/1170x658withlogo_450865576" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Krishna Vani</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-183"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-183/channel_web/1170x658withlog_1124442022" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Hare Krsna</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-284"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-284/channel_web/1170x658withlogo_844800250" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Sadhna TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-285"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-285/channel_web/1170x658withlog_1126976137" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Ishwar  TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-316"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-316/channel_web/1170x658withlog_1836335736" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Awakening</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-345"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-345/channel_web/1170x658withlogo_361016754" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Ek Onkar</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-412"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-412/channel_web/1170x658_1626283630" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Devam</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-wion"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-wion/channel_web/wionpalkisharmaupadhyay" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">WION</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-273"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-273/channel_web/1170x658withlog_2139188797" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News X</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-389"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-389/channel_web/1170x658_1189289223" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Euro News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-170"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-170/channel_web/1170x658withlog_2090292605" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News Nation</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-171"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-171/channel_web/1170x658withlogo_217868396" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News State Uttar Pradesh Uttrakhand</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-172"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-172/channel_web/1170x658withlog_1325098382" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News State Madhya Pradesh Chhattisgarh</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-260"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-260/channel_web/1170x658withlog_1673213675" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV9 Gujarati</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zee24kalak"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zee24kalak/channel_web/1170x658withlog_1335796285" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee 24 Kalak</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-163"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-163/channel_web/1170x658withlogo_382762389" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Shiksha TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddgirnar"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddgirnar/channel_web/1170x658withlog_1445842484" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Girnar</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeecinemahd"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeecinemahd/channel_web/1170x658withlogo_167952257" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Cinema HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-tvpictureshd"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-tvpictureshd/channel_web/1170x658withlog_1476130363" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">&amp;Pictures HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeeanmolcinema"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeeanmolcinema/channel_web/1170x658withlog_1721007595" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Anmol Cinema</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeeclassic"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeeclassic/channel_web/1170x658withlogo_218202605" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Bollywood</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeecinema"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeecinema/channel_web/1170x658withlogo_807278654" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Cinema</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-pictures"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-pictures/channel_web/1170x658withlog_1269578414" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">&amp;Pictures</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeeaction"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeeaction/channel_web/1170x658withlog_1953200347" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Action</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-176"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-176/channel_web/1170x658withlogo_673971588" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Classic</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-170"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-170/channel_web/1170x658withlog_2090292605" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News Nation</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-171"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-171/channel_web/1170x658withlogo_217868396" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News State Uttar Pradesh Uttrakhand</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-172"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-172/channel_web/1170x658withlog_1325098382" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News State Madhya Pradesh Chhattisgarh</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-163"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-163/channel_web/1170x658withlogo_382762389" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Shiksha TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-259"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-259/channel_web/1170x658withlogo_382506495" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV9 Kannada</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-201"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-201/channel_web/1170x658withlog_1629853975" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Suvarna News</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeekannada"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeekannada/channel_web/1170x658_611455469" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Kannada HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddchandana"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddchandana/channel_web/1170x658withlogo_222569298" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Chandana</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-227"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-227/channel_web/1170x658_1957432816" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV5 Kannada</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-241"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-241/channel_web/1170x658withlog_1692640342" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Picchar</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-356"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-356/channel_web/1170x658withlog_1495734600" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">News First</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-377"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-377/channel_web/1170x658withlog_1939892250" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">BTV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-207"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-207/channel_web/09207e24_list" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">E24</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-348"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-348/channel_web/1170x658withlog2096037619" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Zest HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-271"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-271/channel_web/1170x658withlog_1625066572" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Sugran TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-392"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-392/channel_web/1170x658_11759167" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Fashion TV Mumbai</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-393"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-393/channel_web/1170x6581715566364" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Fashion TV Paris</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-129"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-129/channel_web/1170x658withlogo_268830785" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Keralam HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddmalayalam"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddmalayalam/channel_web/1170x658withlog_1300475155" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Malayalam</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-257"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-257/channel_web/1170x658withlog_1579827656" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV9 Marathi</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-270"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-270/channel_web/1170x658withlogo_688844399" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Saam TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeemarathi"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeemarathi/channel_web/1170x658withlogo_551054149" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Marathi HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeeyuva"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeeyuva/channel_web/1170x658withlogo_361849131" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Yuva</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeetalkies"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeetalkies/channel_web/1170x658_483062857" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Talkies HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-134"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-134/channel_web/1170x658withlog_1510286564" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">9X Jhakaas</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddsahyadri"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddsahyadri/channel_web/1170x658withlog_1078376781" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Sahyadri</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-271"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-271/channel_web/1170x658withlog_1625066572" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Sugran TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-353"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-353/channel_web/1170x658withlog_1434429781" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Vajwa</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zing"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zing/channel_web/1170x658withlogo895666865" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zing</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-165"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-165/channel_web/1170x658withlog_1849594732" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Boogle Bollywood</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-296"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-296/channel_web/1170x658_419268810" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Non-stop EDM</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-353"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-353/channel_web/1170x658withlog1434429781" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Vajwa</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeekalinganews"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeekalinganews/channel_web/1170x658withlog_1893514287" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Odisha</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddodia"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddodia/channel_web/1170x658withlog_1372768736" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Odia</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeepunjabharyanahima"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeepunjabharyanahima/channel_web/1170x658withlog_1111951312" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Punjab Haryana Himachal Pradesh</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-215"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-215/channel_web/1170x658withlog_1031170304" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Punjabi</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-chardiklatimetvtimet"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-chardiklatimetvtimet/channel_web/1170x658withlog_1413076946" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Chardikla Time TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-132"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-132/channel_web/1170x658withlogo_790675165" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">9X Tashan</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-channel_2132977507"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-channel_2132977507/channel_web/1170x658withlog_1071598760" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Alpha ETC Punjabi</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddpunjabi"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddpunjabi/channel_web/1170x658withlog_1007647800" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Punjabi</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-274"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-274/channel_web/1170x658withlogo_212610744" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">India News Punjabi Himachal</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-305"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-305/channel_web/1170x658withlogo_941446093" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Living India</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-384"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-384/channel_web/1170x658_1283511414" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Dainik Savera</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-388"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-388/channel_web/1170x658_290485787" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Sanjhi Soch</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-306"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-306/channel_web/1170x658withlog_1787137922" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Vendhar TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeetamil"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeetamil/channel_web/1170x658_1250786368" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Tamil HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-makkaltv"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-makkaltv/channel_web/1170x658withlogo_579936187" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Makkal TV</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-ddpodhigai"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-ddpodhigai/channel_web/1170x658withlog_1550486077" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">DD Podhigai</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-258"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-258/channel_web/1170x658withlogo_100879400" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">TV9 Telugu</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeetelugu"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeetelugu/channel_web/1170x658_593933473" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Telugu HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-zeecinemalu"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-zeecinemalu/channel_web/1170x658_1642453232" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">Zee Cinemalu HD</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-355"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-355/channel_web/1170x658withlogo_719952414" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">ABN Andhra Jyothy</p></div></a></div>

<div class="box1">  <a class="card" href="playzee.php?c=0-9-371"> <img class="lazyload" src="https://akamaividz2.zee5.com/image/upload/resources/0-9-371/channel_web/1170x658withlogo_203787503" alt="Telegram @techmaxpro"><div class="card-body"> <p class="card-text">10TV</p></div></a></div>



</div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
              <script>
$(document).ready(function(){
  $("input").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $(".box1").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});


</script>

</body></html>